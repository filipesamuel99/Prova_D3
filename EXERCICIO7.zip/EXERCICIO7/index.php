<?php

class SuperHeroi {
    private $id;
    private $nome;
    private $poderEspecial;
    private $energia;
    private $forca;
    private $origem;
    
    public function __construct($id, $nome, $poderEspecial, $energia, $forca, $origem){
        $this->id = $id;
        $this->nome = $nome;
        $this->poderEspecial = $poderEspecial;
        $this->energia = $energia;
        $this->forca = $forca;
        $this->origem = $origem;
    }

        


    public function getId(){
        return $this->id;
    }
    public function setId($id){
        $this->id = $id;
    }

    public function getNome(){
        return $this->nome;
    }
    public function setNome($nome){
        $this->nome = $nome;
    }

    public function getPoderEspecial(){
        return $this->poderEspecial;
    }
    public function setPoderEspecial($poderEspecial){
        $this->poderEspecial = $poderEspecial;
    }

    public function getEnergia(){
        return $this->energia;
    }
    public function setEnergia($energia){
        $this->energia = $energia;
    }

    public function getForca(){
        return $this->forca;
    }
    public function setForca($forca){
        $this->forca = $forca;
    }

    public function getOrigem(){
        return $this->origem;
    }
    public function setOrigem($origem){
        $this->origem = $origem;
    }    
    
    
    public function aumentarEnergia($energia){
        $ra = 119126372;
        $this->energia = $energia * $ra;
        return $energia;
    }
    
    public function calcularPoderMedio($energia, $forca){
    	$media = ($energia+$forca)/2;
        $this->media = $media;
        return $media; 
    }
    
   
}



$obj = new SuperHeroi(1, "HarryPotter","Expectro Patronum", 20, 8, "Hogwarts");
$obj1 = new SuperHeroi(2, "Goku", "Instinto Superior", 10, 25, "Planeta Vegeta");
$obj2 = new SuperHeroi(3, "Naruto", "Modo Sennin", 16, 21, "Konoha");
$obj3 = new SuperHeroi(4, "Tanjiro", "Dança do Sol", 30, 30, "Floresta");


//var_dump($obj);
//var_dump($obj1);
//var_dump($obj2);
//var_dump($obj3);

//echo $obj->aumentarEnergia(20);
//var_dump($obj);



?>